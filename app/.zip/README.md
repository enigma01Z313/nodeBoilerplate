# V1.0.0

GET Book/Author/Tag/Category/Filemanager
